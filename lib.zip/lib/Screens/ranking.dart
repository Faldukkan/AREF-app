import 'package:flutter/material.dart';

class Ranking_list extends StatefulWidget {
  const Ranking_list({super.key});

  @override
  State<Ranking_list> createState() => _Ranking_listState();
}

class _Ranking_listState extends State<Ranking_list> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: SafeArea(
            child: Scaffold(
                body: Center(
                    child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(children: [
            SizedBox(
              height: 20,
            ),
            Text(
              " :المتصدرين",
              style: TextStyle(
                fontFamily: "blod",
                fontSize: 30,
              ),
            ),
            SizedBox(
              height: 18,
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10)),
              width: 400,
              height: 55,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                //   Icon(Icons.number)
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("نورة الأحمد",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: "mid",
                          fontSize: 22,
                          color: Colors.black45)),
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10)),
              width: 400,
              height: 55,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("عبدالله سعد",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: "mid",
                          fontSize: 22,
                          color: Colors.black45)),
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10)),
              width: 400,
              height: 55,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("دانا خالد",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: "mid",
                          fontSize: 22,
                          color: Colors.black45)),
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10)),
              width: 400,
              height: 55,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("نواف سالم",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: "mid",
                          fontSize: 22,
                          color: Colors.black45)),
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10)),
              width: 400,
              height: 55,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("Sami",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: "mid",
                          fontSize: 22,
                          color: Colors.black45)),
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10)),
              width: 400,
              height: 55,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("الجوهرة",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: "mid",
                          fontSize: 22,
                          color: Colors.black45)),
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10)),
              width: 400,
              height: 55,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("سلطان يحيى",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: "mid",
                          fontSize: 22,
                          color: Colors.black45)),
                ),
              ]),
            ),
          ]),
        )))));
  }
}
